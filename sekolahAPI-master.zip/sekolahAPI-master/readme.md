# Tugas Lumen sekolahAPI
# IsepSopianDani# XII-RPL3
Tugas : membuat tabel t_kelas menggunakan migration beserta CRUD data nya

